
library(RColorBrewer)
library(tidygeocoder)
library(sf)
library(camcorder)
library(scico)
library(rnaturalearth)
library(terra)
library(tidyterra)
library(geodata)
library(patchwork)
library(ggplot2)
library(readr)

rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("each indicator normalized score.csv",show_col_types = FALSE)
#land
Indicator_prod$cutt <- cut(Indicator_prod$land,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p1<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
    legend.position = "",
    legend.title  = element_blank(),
    legend.text  = element_text(size = 10,face="bold"),
    legend.key.width = unit(1, "lines"),
    legend.key.height = unit(1, "lines"),
    plot.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

#energy
Indicator_prod$cutt <- cut(Indicator_prod$energy,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p2<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))


#freshwater
Indicator_prod$cutt <- cut(Indicator_prod$freshwater,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p3<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

#GHG
Indicator_prod$cutt <- cut(Indicator_prod$GHG,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p4<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))


#N
Indicator_prod$cutt <- cut(Indicator_prod$N,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p5<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))


#P
Indicator_prod$cutt <- cut(Indicator_prod$P,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p6<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

#food
Indicator_prod$cutt <- cut(Indicator_prod$food,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p7<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

#economy
Indicator_prod$cutt <- cut(Indicator_prod$economy,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Country"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

p8<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))



#legend
source("plot_discrete_cbar.R")
x<-plot_discrete_cbar(c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf), colors = col,  width = 1,
                      font_size = 9,legend_title="CSS",spacing="constant")
ggsave("legend.pdf",x,width = 11, height = 3)


