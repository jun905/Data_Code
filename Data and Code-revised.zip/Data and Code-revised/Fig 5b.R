library(tidyverse)
library(Ternary)
library(ggtern)
library(eoffice)
library(ggplot2)
library(ggrepel)
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
df <- read_csv('tu.csv')
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")

p <- ggtern(data=df, aes(x=Resource, y=Environment, z=Benefits),face="bold") + 
  geom_mask() + 
  geom_point(aes(color=Continent),alpha=0.6,size=4)+
  scale_size(range = c(5, 12)) +
  theme_bw() +
  theme(axis.title = element_text(size=18,face = "bold"),
        axis.text =element_text(size=15,face = "bold"),
        axis.ticks.length =unit(1,'cm'))+
  guides(color=guide_legend(override.aes = list(size=8)))+
  theme(legend.title = element_text(size=18,face="bold"))+
  theme(legend.text = element_text(size=15))+
  theme(legend.position = "right",
        plot.margin=margin(0,0,0,0))+
  scale_color_manual(values =my_colors)
 
p
ggsave("ternary diagram.pdf", p, width = 8, height = 6)


