library(tidyverse)
library(sf)
library(camcorder)
library(RColorBrewer)


###societal benefits map
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("societal benefits map.csv",show_col_types = FALSE)
Indicator_prod$cutt <- cut(Indicator_prod$Score,c(0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(2,3,4,5,7,8,9,10,11)]

SBS<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
    legend.position = "",
    legend.title  = element_blank(),
    legend.text  = element_text(size = 10,face="bold"),
    legend.key.width = unit(1, "lines"),
    legend.key.height = unit(1, "lines"),
    plot.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

ggsave("societal benefits map.pdf", SBS, width = 8, height = 6)




###environmental pollution map
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("environmental pollution map.csv",show_col_types = FALSE)
Indicator_prod$cutt <- cut(Indicator_prod$Score,c(-Inf,0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(1,2,3,4,5,7,8,9,10,11)]

EPS<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

ggsave("environmental pollution map.pdf", EPS, width = 8, height = 6)




###resource utilization map
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("resource utilization map.csv",show_col_types = FALSE)
Indicator_prod$cutt <- cut(Indicator_prod$Score,c(0, 25, 35, 45, 50, 55, 65, 75, 100,Inf),include.lowest = T)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 


col<-RColorBrewer::brewer.pal(11, "RdBu")[c(2,3,4,5,7,8,9,10,11)]

RUS<-ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.2,alpha=0) +
  geom_sf(aes(fill = cutt)) +
  scale_fill_manual(values = col,na.value = "grey",na.translate = F)+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5,size=16,face="bold"),
        legend.position = "",
        legend.title  = element_blank(),
        legend.text  = element_text(size = 10,face="bold"),
        legend.key.width = unit(1, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))+
  guides(fill= guide_legend(nrow=1))

ggsave("resource utilization map.pdf", RUS, width = 8, height = 6)






