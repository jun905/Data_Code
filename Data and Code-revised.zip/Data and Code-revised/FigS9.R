library(tidyverse)
library(magrittr)
library(ggsci)
library(stats)
library(rstatix)
library(multcompView)
library(ggpubr)

rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
#land use score
df <- read.csv("LAI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
LAI <- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=150,label=comL$Letters,size = 6)+
  labs(x=NULL, y="Land use score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))

##energy use score
df <- read.csv("ENI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
ENI <- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=150,label=comL$Letters,size = 6)+
  labs(x=NULL, y="Energy use score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))

##freshwater use score
df <- read.csv("FRI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
FRI <- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=150,label=comL$Letters,size = 6)+
  labs(x=NULL, y="Freshwater use score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))


##GHG emissions score
df <- read.csv("CI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
GHG <- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=125,label=comL$Letters,size = 6)+
  labs(x=NULL, y="GHG emissions score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))

##N emissions score
df <- read.csv("NI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
NI <- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=250,label=comL$Letters,size = 6)+
  labs(x=NULL, y="N emissions score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))
##P emissions score
df <- read.csv("PI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
  pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
m <- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=175,label=comL$Letters,size = 6)+
  labs(x=NULL, y="Phosphorus emissions score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
    axis.text.y = element_text(size = 15,color="black",face="bold"),
    axis.title.y= element_text(size=18,color="black",face="bold"),
    #axis.title.x = element_text(size = 25,color="black",face="bold"),
    legend.title=element_blank(),
    legend.key=element_blank(), 
    legend.box.background = element_blank(),
    legend.text = element_text(color="black",size=12,face="bold"),
    legend.spacing.y = unit(0.3,"cm"),
    legend.spacing.x=unit(0.1,'cm'), 
    legend.key.width=unit(0.3,'cm'), 
    legend.key.height=unit(0.3,'cm'),
    legend.background=element_blank(), 
    legend.position="",legend.justification=c(1,1))

##food provide score
df <- read.csv("FOI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
FOI<- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=125,label=comL$Letters,size = 6)+
  labs(x=NULL, y="Food provide score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))


##economy provide score
df <- read.csv("ECI.csv")
kruskal.test(Score~Continent,data=df)#
b <- with(data=df,
          pairwise.wilcox.test(x=Score,g=Continent))#,p.adjust.method = "holm"

bp<-b$p.value
bp<-cbind(bp,rep(NA,5))
bp<-rbind(rep(NA,6),bp)
colnames(bp)[6]<-"Oceania"
rownames(bp)[1]<-"Africa"
bp<-round(bp,5)
bp[upper.tri(bp)]<- t(bp)[upper.tri(bp)]
# change order
bp<-bp[c(5,3,4,1,2,6),c(5,3,4,1,2,6)]
comL<-multcompLetters(bp)

plot(bp)
df$Continent <- factor(df$Continent,levels = c("N America","C&S America","Europe","Africa","Asia","Oceania"))
my_colors <- c("#EE4C9799", "#00A087B2", "#6F99ADE5", 
               "#F0E685FF", "#7876B1E5", "#7E6148B2")
ECI<- 
  ggplot(df,aes(x=Continent,y=Score,fill=Continent))+
  geom_violin(position = position_dodge(width = 0.1), scale = 'width',width=0.6)+ 
  stat_boxplot(geom="errorbar",position = position_dodge(width = 0.1),width=0.05)+
  geom_boxplot(alpha=1,outlier.size=0, size=0.3, width=0.1,fill="white")+
  annotate("text",x=1:6,y=475,label=comL$Letters,size = 6)+
  labs(x=NULL, y="Economy provide score")+
  scale_fill_manual(values =my_colors)+
  theme_test() + 
  theme(axis.text.x = element_text(size = 15,color="black",face="bold",angle = 45,vjust = 1,hjust=1),
        axis.text.y = element_text(size = 15,color="black",face="bold"),
        axis.title.y= element_text(size=18,color="black",face="bold"),
        #axis.title.x = element_text(size = 25,color="black",face="bold"),
        legend.title=element_blank(),
        legend.key=element_blank(), 
        legend.box.background = element_blank(),
        legend.text = element_text(color="black",size=12,face="bold"),
        legend.spacing.y = unit(0.3,"cm"),
        legend.spacing.x=unit(0.1,'cm'), 
        legend.key.width=unit(0.3,'cm'), 
        legend.key.height=unit(0.3,'cm'),
        legend.background=element_blank(), 
        legend.position="",legend.justification=c(1,1))






