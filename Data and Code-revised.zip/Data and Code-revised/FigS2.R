library(tidyverse)
library(maps)
library(patchwork)

rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()

df <- read.csv("Composite score for each continent.csv")



#North America
bar_amer<-df%>%filter(Continent %in% c('North Americas'))%>%arrange(Continent, -Score)
bar_amer$id <- seq(1, nrow(bar_amer))
number_of_bar_amer <- nrow(bar_amer)
angle_amer <- 90 - 360 * (bar_amer$id-0.5) /number_of_bar_amer 
bar_amer$hjust <- ifelse( angle_amer < -90, 1, 0)
bar_amer$angle <- ifelse(angle_amer < -90, angle_amer+180, angle_amer)

#Central and South America
bar_SA<-df%>%filter(Continent %in% c('Med South Americas'))%>%arrange(Continent, -Score)
bar_SA$id <- seq(1, nrow(bar_SA))
number_of_bar_SA <- nrow(bar_SA)
angle_SA <- 90 - 360 * (bar_SA$id-0.5) /number_of_bar_SA 
bar_SA$hjust <- ifelse( angle_SA < -90, 1, 0)
bar_SA$angle <- ifelse(angle_SA < -90, angle_SA+180, angle_SA)

#Africa
bar_afr<-df%>%filter(Continent %in% c('Africa'))%>%arrange(Continent, -Score)
bar_afr$id <- seq(1, nrow(bar_afr))
number_of_bar_afr <- nrow(bar_afr)
angle2 <- 90 - 360 * (bar_afr$id-0.5) /number_of_bar_afr
bar_afr$hjust <- ifelse( angle2 < -90, 1, 0)
bar_afr$angle <- ifelse(angle2 < -90, angle2+180, angle2)

#Asia
bar_asi<-df%>%filter(Continent %in% c('Asia'))%>%arrange(Continent, -Score)
bar_asi$id <- seq(1, nrow(bar_asi))
number_of_bar_asi <- nrow(bar_asi)
angle2 <- 90 - 360 * (bar_asi$id-0.5) /number_of_bar_asi
bar_asi$hjust <- ifelse( angle2 < -90, 1, 0)
bar_asi$angle <- ifelse(angle2 < -90, angle2+180, angle2)

#Europe
bar_eur<-df%>%filter(Continent %in% c('Europe'))%>%arrange(Continent, -Score)
bar_eur$id <- seq(1, nrow(bar_eur))
number_of_bar_eur <- nrow(bar_eur)
angle2 <- 90 - 360 * (bar_eur$id-0.5) /number_of_bar_eur
bar_eur$hjust <- ifelse( angle2 < -90, 1, 0)
bar_eur$angle <- ifelse(angle2 < -90, angle2+180, angle2)

#Ocean
bar_oce<-df%>%filter(Continent %in% c('Oceania'))%>%arrange(Continent, -Score)
bar_oce$id <- seq(1, nrow(bar_oce))
number_of_bar_oce <- nrow(bar_oce)
angle2 <- 90 - 360 * (bar_oce$id-0.5) /number_of_bar_oce
bar_oce$hjust <- ifelse( angle2 < -90, 1, 0)
bar_oce$angle <- ifelse(angle2 < -90, angle2+180, angle2)

#North America
p1 <- ggplot(bar_amer, aes(x=as.factor(id), y=Score, fill=Score)) +       
  geom_bar(stat="identity") +
  geom_text(aes(x=as.factor(id), y=Score+3, label=Country,
                hjust=hjust, angle=angle), color="black",
             size=5.3, inherit.aes = FALSE )+ 
  scale_fill_gradientn(limits= c(15,120),
                       colours = RColorBrewer::brewer.pal(11,"RdBu"),
                       guide=guide_colorbar(title.position = "top",
                                            barwidth = 15))+
  ylim(-100,93) +
  theme_void() + 
  coord_polar()+
  theme(legend.position="top",legend.title = element_blank())+
  theme(legend.text =element_text(size = 15,hjust = 0.5,vjust = 0.5,face = "bold") )

#Central and South America
p6 <- ggplot(bar_SA, aes(x=as.factor(id), y=Score, fill=Score)) +       
  geom_bar(stat="identity") +
  geom_text(aes(x=as.factor(id), y=Score+3, label=Country,
                hjust=hjust, angle=angle), color="black",
            size=5.3, inherit.aes = FALSE )+ 
  scale_fill_gradientn(limits= c(15,120),
                       colours = RColorBrewer::brewer.pal(11,"RdBu"),
                       guide=guide_colorbar(title.position = "top",
                                            barwidth = 15))+
  ylim(-100,121) +
  theme_void() + 
  coord_polar()+
  theme(legend.position="top",legend.title = element_blank())+
  theme(legend.text =element_text(size = 15,hjust = 0.5,vjust = 0.5,face = "bold") )

#Africa
p2 <- ggplot(bar_afr, aes(x=as.factor(id), y=Score, fill=Score)) +       
  geom_bar(stat="identity") +
  geom_text(aes(x=as.factor(id), y=Score+3, label=Country, hjust=hjust,
                angle=angle), color="black",
            size=5.3, inherit.aes = FALSE )+ 
  scale_fill_gradientn(limits= c(15,120),
                       colours =RColorBrewer::brewer.pal(11,"RdBu"),
                       guide=guide_colorbar(title.position = "top",
                                            barwidth = 15))+
  ylim(-100,106) +
  theme_void() + 
  coord_polar()+
  theme(legend.position="top",legend.title = element_blank())+
  theme(legend.text =element_text(size = 15,hjust = 0.5,vjust = 0.5,face = "bold") )

#Asia
p3 <- ggplot(bar_asi, aes(x=as.factor(id), y=Score, fill=Score)) +       
  geom_bar(stat="identity") +
  geom_text(aes(x=as.factor(id), y=Score+3, label=Country, hjust=hjust,
                angle=angle), color="black",
            size=5.3, inherit.aes = FALSE )+ 
  scale_fill_gradientn(limits= c(15,120),
                       colours =RColorBrewer::brewer.pal(11,"RdBu"),
                       guide=guide_colorbar(title.position = "top",
                                            barwidth = 15))+
  ylim(-100,80) +
  theme_void() + 
  coord_polar()+
  theme(legend.position="top",legend.title = element_blank())+
  theme(legend.text =element_text(size = 15,hjust = 0.5,vjust = 0.5,face = "bold") )

#Europe
p4 <- ggplot(bar_eur, aes(x=as.factor(id), y=Score, fill=Score)) +       
  geom_bar(stat="identity") +
  geom_text(aes(x=as.factor(id), y=Score+3, label=Country, hjust=hjust,
                angle=angle), color="black",
            size=5.3, inherit.aes = FALSE )+ 
  scale_fill_gradientn(limits= c(15,120),
                       colours =RColorBrewer::brewer.pal(11,"RdBu"),
                       guide=guide_colorbar(title.position = "top",
                                            barwidth = 15))+
  ylim(-100,91) +
  theme_void() + 
  coord_polar()+
  theme(legend.position="top",legend.title = element_blank())+
  theme(legend.text =element_text(size = 15,hjust = 0.5,vjust = 0.5,face = "bold") )


#Ocean
p5 <- ggplot(bar_oce, aes(x=as.factor(id), y=Score, fill=Score)) +       
  geom_bar(stat="identity") +
  geom_text(aes(x=as.factor(id), y=Score+3, label=Country, hjust=hjust,
                angle=angle), color="black",
            size=5.3, inherit.aes = FALSE )+ 
  scale_fill_gradientn(limits= c(15,120),
                       colours =RColorBrewer::brewer.pal(11,"RdBu"),
                       guide=guide_colorbar(title.position = "top",
                                            barwidth = 15))+
  ylim(-100,103) +
  theme_void() + 
  coord_polar()+
  theme(legend.position="top",legend.title = element_blank())+
  theme(legend.text =element_text(size = 15,hjust = 0.5,vjust = 0.5,face = "bold") )+
  theme(plot.margin = margin(t = 0, r = 0,b = 0,l = 0, unit = "cm"))


Northamerica <- p1 

Southamerica <- p6

Africa<- p2

Asia<- p3

Europe<- p4 

Ocean<- p5

Northamerica
Southamerica
Africa
Asia
Europe
Ocean
















