library(tidyverse)
library(ggsci)
library(ggplot2)

rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()

rel_phy<- read_csv("percentage of number for each country.csv")
rel_phy$Interval=factor(rel_phy$Interval,
                   levels = c("0-25", "25-50", "50-75", "75-100",">100"))


allu <- ggplot(data = rel_phy,
               aes(x = Continent, y =Score, fill = Interval)) +
  geom_bar(aes(fill = Interval),stat='identity', width=0.45) +
  scale_y_continuous(expand=c(0, 0))+
  theme_bw() +
  theme(
    legend.position = "top",
    panel.grid=element_blank(),
    panel.spacing.x = unit(0,units = "cm"),
    strip.placement = "outside",
    axis.text = element_text(face = "bold", 
                             size = 12,color="black"),
    axis.title = element_text(face = "bold", 
                              size = 12,colour = "black"),
    legend.title = element_text(face = "bold", 
                                size =16,color="black"),
    legend.text = element_text(face = "bold", size =12),
    axis.ticks.x = element_blank(),
    axis.ticks.y = element_line(size = 0.3),
    
  )+
  labs(x = "",y= "Percentage of numbers in each interval (%)")+
  scale_fill_locuszoom()
allu
ggsave("percentage of number for each country.png",allu,width = 8, height = 6)





