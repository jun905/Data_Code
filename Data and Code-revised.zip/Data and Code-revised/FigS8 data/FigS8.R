library(tidyverse)
library(sf)
library(camcorder)
library(RColorBrewer)
library(tidygeocoder)
library(scico)
library(rnaturalearth)
library(terra)
library(tidyterra)
library(geodata)
library(patchwork)
#####land
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("land.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

land <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = land)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
    legend.title = element_blank(),
    legend.text  = element_text(size = 15,face="bold"),
    legend.key.width = unit(3.5, "lines"),
    legend.key.height = unit(1, "lines"),
    plot.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(0, 0, 0, 0))




###energy
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("energy.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

energy <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = energy)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))




###freshwater
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("freshwater.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

freshwater <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = water)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))



###GHG
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("GHG.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

GHG <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = GHG)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))




###N
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("N.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

N <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = N)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))




###P
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("P.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

P <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = P)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))




###food
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("food.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

food <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = food)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))





###economy
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("economy.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

economy <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = economy)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))





###GDP
world <- read_sf("world.zh.json")%>% 
  janitor::clean_names()

Indicator_prod <- read_csv("GDP.csv",show_col_types = FALSE)

Indicator_world <- world %>% 
  left_join(Indicator_prod, by = c("iso_a3" = "Code"))

crs_wintri <- "+proj=wintri +datum=WGS84 +no_defs +over"

Indicator_world_wintri <- lwgeom::st_transform_proj(Indicator_world, crs = crs_wintri)



grat_wintri <- st_graticule(lat = c(-89.9, seq(-80, 80, 40), 89.9),
                            lon =c(-179.9, seq(-160, 160, 40), 179.9) ) %>%
  lwgeom::st_transform_proj(crs = crs_wintri)

lats <- c(90:-90, -90:90, 90)
longs <- c(rep(c(180, -180), each = 181), 180)

wintri_outline <- 
  list(cbind(longs, lats)) %>%
  st_polygon() %>%
  st_sfc(crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs") %>% 
  st_sf() %>%
  lwgeom::st_transform_proj(crs = crs_wintri) 

GDP <- ggplot(Indicator_world_wintri) +
  geom_sf(data = wintri_outline, fill = "white", color = NA,alpha=0.5) +
  geom_sf(data = grat_wintri, color = "grey60", linewidth = 0.03,alpha=0) +
  geom_sf(aes(fill = GDP)) +
  scale_fill_gradientn(colors = RColorBrewer::brewer.pal(11, "RdBu"), na.value = "grey60")+
  coord_sf(datum = NULL) +
  theme_void() +
  theme(legend.position = "top",
        legend.title = element_blank(),
        legend.text  = element_text(size = 15,face="bold"),
        legend.key.width = unit(3.5, "lines"),
        legend.key.height = unit(1, "lines"),
        plot.background = element_rect(fill = "white", color = NA),
        plot.margin = margin(0, 0, 0, 0))


