
library(devtools)
library(ggplot2)
library(ggradar)
library(magrittr)
library(ggsci)
library(eoffice)
test_data <- data.frame(row.names = c('Africa','Asia','C&S America','Europe','N America','Oceania'),
                        RU = c(47.5243105,32.63747928,43.11802824,52.77912473,41.40297041,46.87087834),
                        EP = c(51.11628241,42.86046265,45.34045767,63.84687835,57.06193318,56.13549144),
                        SB = c(43.39315225,59.54634337,74.98155404,63.82346455,74.17106907,68.29031815))

data_pro <- test_data %>% tibble::rownames_to_column(var = "group")
plot_ggradar_single <- ggradar(data_pro[1,],values.radar = c("0", "40","80"),
                               grid.min = 0, grid.mid = 40, grid.max =80)
ggradar_single_set <- ggradar(data_pro[1,],
                              font.radar = "sans",
                              values.radar = c("0", "40", "80"),
                              grid.min = 0, grid.mid = 40, grid.max = 80,
                              grid.label.size = 6,
                              grid.line.width = 1,
                              gridline.min.colour = "#A5DFF9",
                              gridline.mid.colour = "#EF5285",
                              gridline.max.colour = "#60C5BA",
                              group.colours = "#30A9DE",
                              group.line.width = 1.2,
                              group.point.size = 4,
                              background.circle.colour = "#FEEE7D",
                              axis.label.size = 6,
                              plot.legend = "TRUE",
                              legend.position = "top",
                              legend.title = "",
                              legend.text.size = 20) +
  theme(plot.margin = margin(t = 0, r = -8,b = 0,l = 0, unit = "cm"))+
  theme(plot.margin = margin(0, 0, 0, 0))
ggradar_single_set


ggradar_mult <-ggradar(
  data_pro,
  values.radar = c("0", "40", "80"),
  grid.min = 0, grid.mid = 40, grid.max = 80,
  group.line.width = 1, 
  group.point.size = 3,
  grid.line.width = 1.2,
  gridline.min.colour = "#A5DFF9",
  gridline.mid.colour = "#EF5285",
  gridline.max.colour = "#60C5BA",
  background.circle.colour = "white",
  legend.position = "right",legend.text.size = 20
)
ggradar_mult

ggsave("Radar chart.png",ggradar_mult,width=10,height=6)








