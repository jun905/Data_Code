if (!requireNamespace("devtools")) install.packages("devtools")
devtools::install_github("caijun/ggcorrplot2")
install.packages("gglayer")
library(dplyr)
library(ggplot2)
library(psych)# corr.test
library(ggcorrplot2)
library(ggplot2)
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
data<-read.csv("correlation analysis for Fig5a.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,4:7],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
x<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
  insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))
x
ggsave("correlation analysis for Fig5a.pdf", x, width = 8, height = 8)






