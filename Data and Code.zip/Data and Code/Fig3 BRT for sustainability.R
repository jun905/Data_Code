
rm(list=ls());gc()
library(ggBRT)
library(dplyr)
library(ggsci)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
div_env <- read.csv("BRT data.csv")

load("opest")
source("ggPD_su 2.R")


res<-NULL 
con<-data.frame(var=NA) 
set.seed(2024)
for(i in 1:100)
{
  gbm <- gbm.step(data=div_env, gbm.x = 4:11, gbm.y = 3,
                  tree.complexity = opest[1,2], family = "gaussian",#poisson
                  learning.rate =opest[1,3], bag.fraction = opest[1,1],plot.main = F)
  D2<-(gbm$self.statistics$mean.null-gbm$cv.statistics$deviance.mean)/gbm$self.statistics$mean.null
  res<-c(res,D2) # %
  summary_df <- as.data.frame(summary(gbm, plot = F))
  con <- left_join(summary_df, con, by = "var")
}
invaInf<-rbind(con,c(NA,res))
colnames(invaInf)[-1]<-"inf"
invaInf$mean<-apply(invaInf[,-1],1,mean)
getwd()
save(invaInf, file="BRT 100 loop")

load("BRT 100 loop")
View(invaInf)
conM<-invaInf[,c(1,102)]
# plot figure
# for plot 
set.seed(2024)
gbm <- gbm.step(data=div_env, gbm.x = 4:11, gbm.y = 3,
                tree.complexity = opest[1,2], family = "gaussian",#poisson
                learning.rate = opest[1,3], bag.fraction = opest[1,1],plot.main = F)
# change contri to mean value
cont<-left_join(gbm$contributions,conM,by="var")
gbm$contributions[,2]<-cont[,3]
conM[9,]# mean D2 0.5932537


png("BRT.png",width=6000,height=3000,res=600) 
ggPD_su(gbm,rug = T,smooth = T,mod="loess",span=0.6,cex.smooth=1,y.label = "Composite sustainability score")


dev.off()


library(circlize)
find.int <- gbm.interactions(gbm)
x<-find.int$interactions
find.int$rank.list
png("factors interaction.png",width=3000,height=3000,res=600)
set.seed(2018)
chordDiagram(t(x), annotationTrack = "grid", preAllocateTracks = 1, link.visible = t(x) >= 0.1)
circos.trackPlotRegion(track.index = 1, panel.fun = function(x, y) {
  xlim = get.cell.meta.data("xlim")
  ylim = get.cell.meta.data("ylim")
  sector.name = get.cell.meta.data("sector.index")
  circos.text(mean(xlim), ylim[1] + .1, sector.name, facing = "clockwise", niceFacing = T, adj = c(0, 0.5))
  circos.axis(h = "top", labels.cex = 0.5, major.tick.percentage = 0.2, sector.index = sector.name, track.index = 2)
}, bg.border = NA)
dev.off()


pdf("bar chart.pdf", width=8,height=5)
ggInfluence(gbm,col.bar = "darkorange")

dev.off()




