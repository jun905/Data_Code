if (!requireNamespace("devtools")) install.packages("devtools")
devtools::install_github("caijun/ggcorrplot2")
install.packages("gglayer")
library(dplyr)
library(ggplot2)
library(psych)# corr.test
library(ggcorrplot2)
library(ggplot2)
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
data<-read.csv("8 indicator raw data.csv" )



## correlation For Fig S1
cor2 <- corr.test(data[,2:9],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
x<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
  insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))
x

data <- read.csv("8 indicator raw data.csv" )
#scale_colour_manual(values=c("black","blue","orange","orangered","purple"))

data$outlier<-NA
sc<-function(x)


scp<-function(x,y="n")
{
  mini<-quantile(x,0.25)-1.5*IQR(x)
  if(mini<min(x)) mini=min(x)
  maxi<-quantile(x,0.75)+1.5*IQR(x)
  if(maxi>max(x)) maxi=max(x)
  if(y=="p")
    (x-mini)/(maxi-mini)*100
  else if(y=="n") (maxi-x)/(maxi-mini)*100
}

data$a4<-scp(data$LAI)
data$b4<-scp(data$ENI)
data$c4<-scp(data$FRI)
data$d4<-scp(data$CI)
data$e4<-scp(data$NI)
data$f4<-scp(data$PI)
data$g4<-scp(data$FOI,y="p")
data$h4<-scp(data$ECI,y="p")

L4<-paste0(letters[1:8],"4")

data$sus4<-apply(cbind(apply(data[,L4[1:3]],1,mean),apply(data[,L4[4:6]],1,mean),apply(data[,L4[7:8]],1,mean)),1,sum)/3


data$Country1<-data$Country
hist(data$sus4)
range(data$sus4)
write.csv(data$sus4,file = "Composite sustainability score.csv")
write.csv(data[,L4],file = "8 indicators normalized score.csv")
#sub-sector score
data$sub1<-apply(data[,L4[1:3]],1,sum)/3
data$sub2<-apply(data[,L4[4:6]],1,sum)/3
data$sub3<-apply(data[,L4[7:8]],1,sum)/2
write.csv(data$sub1,file = "Resource utilization.csv")
write.csv(data$sub2,file = "Environmental pollution.csv")
write.csv(data$sub3,file = "Societal benefits.csv")







