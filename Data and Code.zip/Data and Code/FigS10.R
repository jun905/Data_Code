library(dplyr)
library(ggplot2)
library(psych)# corr.test
library(ggcorrplot2)
library(gam)
library(mgcv)
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()
##CSS
data<-read.csv("correlation analysis for CSS.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
CSS<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
  insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##SBS
data<-read.csv("correlation analysis for SBS.csv" )

## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
SBS<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##EPS
data<-read.csv("correlation analysis for EPS.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
EPS<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##RUS
data<-read.csv("correlation analysis for RUS.csv" )

## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
RUS<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


