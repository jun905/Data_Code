library(dplyr)
library(ggplot2)
library(psych)# corr.test
library(ggcorrplot2)
library(ggplot2)
rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) ###  set the path 
dir()

##land
data<-read.csv("LAI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
LAI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
  insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##energy
data<-read.csv("ENI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
ENI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##freshwater
data<-read.csv("FRI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
FRI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##GHG
data<-read.csv("CI.csv" )

## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
CI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##N
data<-read.csv("NI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
NI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                     insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##P
data<-read.csv("PI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
PI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                     insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##food
data<-read.csv("FOI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
FOI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                     insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))


##economy
data<-read.csv("ECI.csv" )


## correlation supp. figure
cor2 <- corr.test(data[,2:6],method ="spearman")
corr <- cor2$r
p.mat <- cor2$p
ECI<-ggcorrplot.mixed(corr, upper = "ellipse", lower = "number",p.mat = p.mat, 
                      insig = "label_sig", sig.lvl = c(0.05, 0.01, 0.001))










